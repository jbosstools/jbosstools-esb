To run this example, you should create EAP 5.x server runtime in your workspace.
