package org.jboss.soa.esb.samples.quickstart.webserviceproducer.webservice;

import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

import org.jboss.soa.esb.actions.soap.SOAPProcessor;
import org.jboss.soa.esb.message.Message;

/**
 * @author
 */
@WebService(name = "GoodbyeWorldWS", targetNamespace="http://webservice_producer/goodbyeworld")
// @SOAPBinding(style = SOAPBinding.Style.RPC)
public class GoodbyeWorldWS {

    @WebMethod
    public String sayGoodbye(@WebParam(name="message") String message) {

        Message esbMessage = SOAPProcessor.getMessage();
        if(esbMessage != null) {
            System.out.println("**** SOAPRequest perhaps mediated by ESB:\n" + esbMessage.getBody().get());
            // System.out.println("\n" + esbMessage.toString() + "\n");
        }
        System.out.println("Web Service Parameter - message=" + message);
        return "... Ah Goodbye then!!!! - " + message;
    }

    @WebMethod
    public String sayAdios(String message) {
        Message esbMessage = SOAPProcessor.getMessage();
        if(esbMessage != null) {
            System.out.println("**** SOAPRequest perhaps mediated by ESB:\n" + esbMessage.getBody().get());
            // System.out.println("\n" + esbMessage.toString() + "\n");
        }
        System.out.println("Web Service Parameter - message=" + message);
        return "... Adios Amigo!!!! - " + message;
    }
    
    @WebMethod
    @Oneway
    public void sayGoodbyeWithoutResponse(@WebParam(name="message") String message) {

        Message esbMessage = SOAPProcessor.getMessage();
        if(esbMessage != null) {
            System.out.println("**** SOAPRequest perhaps mediated by ESB:\n" + esbMessage.getBody().get());
        }
        System.out.println("Web Service Parameter - message=" + message);
    }
    
}
