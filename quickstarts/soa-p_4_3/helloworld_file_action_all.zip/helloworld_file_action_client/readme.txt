To run this example, you should create EAP server runtime 
with the name "jboss-soa-p.4.3.0 Runtime" in your workspace.

